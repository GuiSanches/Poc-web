<?php
    include("menu.php");

?>
conteúdo da página (minha rede)