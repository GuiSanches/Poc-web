<?php
    include("menu.php"); //warning

    //require "menu2.php"; //fatal error

?>
conteúdo da página (início)
<br />

<?php
    include("menu.php");

?>