# ProjetosWEB

Aqui estão reunidos alguns de meus projetos realizados durante as férias a partir do curso Web Completo da Udemy, com intuito de treinar tecnologias WEB tais como: HTML, CSS, BootStrap, JavaScript, PHP, NodeJS, MySQL, MongoDB.