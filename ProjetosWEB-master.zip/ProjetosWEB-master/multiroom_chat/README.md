### Um chat simples criado a partir de Node.JS, socket.io e Express, por ser rodado na própria máquina não é possível conversar com outras pessoas. Para testá-lo é preciso abrir diferentes abas no navegador.

###### Este projeto visa treinar tecnologias voltadas ao backend utilizando padrão de arquitetura MVC