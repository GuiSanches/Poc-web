module.exports.home = (application, req, res) => {
    res.render("index", {validacao: {}});
}