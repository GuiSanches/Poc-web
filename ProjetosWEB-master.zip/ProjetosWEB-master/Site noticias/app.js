let app = require('./config/server');
app.listen(3000, () => {
    console.log('Servidor ON');
})
